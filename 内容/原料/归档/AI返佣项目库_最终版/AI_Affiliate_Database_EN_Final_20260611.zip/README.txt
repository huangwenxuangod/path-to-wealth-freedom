# AI Affiliate Programs Database - English Edition (Final)

## 📚 Must Read
👉 readme.md / readme.pdf — Complete 30-day Gold SOP

## 📦 Files
| File | Use |
|------|-----|
| readme.md | ⭐ 30-day Gold SOP (Markdown) |
| readme.pdf | ⭐ 30-day Gold SOP (PDF) |
| AI_Affiliate_Database_EN.xlsx | Multi-sheet Excel |
| AI_Affiliate_Database_EN.md | Markdown report |
| AI_Affiliate_Database_EN.pdf | PDF print |
| AI_Affiliate_Database_EN.docx | Word editable |
| AI_Affiliate_Database_EN.csv | Raw CSV |

Curated by: Chegan · College AI Practitioner
